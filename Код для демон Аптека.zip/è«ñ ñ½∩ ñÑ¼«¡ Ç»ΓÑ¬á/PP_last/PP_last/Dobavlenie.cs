﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace PP_last
{
    public partial class Dobavlenie : Form
    {
        DataBase dataBase = new DataBase();

        public Dobavlenie()
        {
            InitializeComponent();
            StartPosition = FormStartPosition.CenterScreen;
        }

        

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            dataBase.openConnection();
            var FIO = textBox1.Text;
            var email = textBox4.Text;
            var pass_s = textBox3.Text;

            var socialtyp = comboBox1.Text;
           
            var phone = textBox4.Text;

            var query = $"insert into patients (fio, email, social_sec_number, social_type, phone, passport_s) values ('{FIO}','{email}','{socialtyp}','{phone}', '{pass_s}')";

            var command = new SqlCommand(query, dataBase.GetConnection());
            //command.ExecuteNonQuery();

            dataBase.closeConnection();
            MessageBox.Show("Пациент успешно зарегистрирован");
            comboBox1.Text = ("");
            textBox4.Text = ("");
            textBox5.Text = ("");

        }
    }
}
