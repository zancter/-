﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PP_last
{
    public partial class Form1 : Form
    {

        DataBase dataBase = new DataBase();

        public Form1()
        {
            InitializeComponent();
            StartPosition = FormStartPosition.CenterScreen;
            textBox_password.UseSystemPasswordChar = false;
        }

        

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void log_in_load(object sender, EventArgs e)
        {
            textBox_password.PasswordChar = '*';
            textBox_login.MaxLength = 50;
            textBox_password.MaxLength = 50;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            var loginUser = textBox_login.Text;
            var passUser = textBox_password.Text;

            SqlDataAdapter adapter = new SqlDataAdapter();
            DataTable table = new DataTable();

            string querystring = $"select id, login, password, type from users where login = '{loginUser}' and password = '{passUser}' ";

            SqlCommand command = new SqlCommand(querystring, dataBase.GetConnection());

            adapter.SelectCommand = command;
            adapter.Fill(table);
            if (table.Rows.Count == 1)
            {
                if (Convert.ToString(table.Rows[0][3]) == "1")
                {
                    Admin_form frm2 = new Admin_form();
                    this.Hide();
                    frm2.ShowDialog();
                    this.Show();

                }
                else if (Convert.ToString(table.Rows[0][3]) == "2")
                {
                    Lab_Form frm3 = new Lab_Form();
                    this.Hide();
                    frm3.ShowDialog();
                    this.Show();
                }
                else
                {
                    Bugalt_Form frm4 = new Bugalt_Form();
                    this.Hide();
                    frm4.ShowDialog();
                    this.Show();

                }
            }
            else
            {
                Captcha_Form frm5 = new Captcha_Form();
                this.Hide();
                frm5.ShowDialog();
                
            }

          }

        private void textBox_password_TextChanged(object sender, EventArgs e)
        {
            textBox_password.PasswordChar = '*';
            textBox_login.MaxLength = 50;
            textBox_password.MaxLength = 50;
          
        }

     

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox1.Checked)
            {
                textBox_password.UseSystemPasswordChar = true;
            }
            else
            {
                textBox_password.UseSystemPasswordChar = false;
            }

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }
    }
}
