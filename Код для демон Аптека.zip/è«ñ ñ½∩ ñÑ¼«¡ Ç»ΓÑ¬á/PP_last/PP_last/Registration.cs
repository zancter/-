﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace PP_last
{
    public partial class Registration : Form
    {

        DataBase dataBase = new DataBase();
        string connectionString = @"Data Source=DESKTOP-0133EL8\SQL5;Initial Catalog=Apteka;Integrated Security=True";
        string query = $"Select barcode from blood where patient = @patient";
        string query1 = $"SELECT fio FROM patients WHERE id = @id";
        string query2 = $"SELECT passport_s FROM patients WHERE id = @id";
        string query3 = $"SELECT passport_n FROM patients WHERE id = @id";
        string query4 = $"SELECT social_sec_number FROM patients WHERE id = @id";
        string query5 = $"SELECT social_type FROM patients WHERE id = @id";

        public Registration()
        {
            InitializeComponent();
            StartPosition = FormStartPosition.CenterScreen;
        }

        private void Registration_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "aptekaDataSet16.patients". При необходимости она может быть перемещена или удалена.
            this.patientsTableAdapter3.Fill(this.aptekaDataSet16.patients);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "aptekaDataSet15.patients". При необходимости она может быть перемещена или удалена.
            this.patientsTableAdapter2.Fill(this.aptekaDataSet15.patients);
            

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            dataBase.openConnection();
            var FIO = textBox2.Text;
            var pass_n = textBox3.Text;
            var socialsec = textBox1.Text;
            var socialtyp = comboBox2.Text;

            var query = $"insert into req (fio, social_sec_number, social_type, passport_n) values ('{FIO}','{socialsec}','{socialtyp}', '{pass_n}')";

            var command = new SqlCommand(query, dataBase.GetConnection());
            command.ExecuteNonQuery();

            dataBase.closeConnection();
            MessageBox.Show("Заявка успешно сформирована");
            comboBox2.Text = ("");
            textBox2.Text = ("");
            textBox3.Text = ("");
            textBox1.Text = ("");
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            // string id_patient = comboBox1.Text;

            //using (SqlConnection connection = new SqlConnection(connectionString))

            //using (SqlCommand command = new SqlCommand(query, connection))
            // {
            // DateTime myDate = DateTime.Now;

            // string formattedDate = myDate.ToString("yyMMdd");

            // command.Parameters.AddWithValue("@patient", id_patient);
            // connection.Open();

            //  string name = (string)command.ExecuteScalar();

            // if (name != null)

            // {
            //textBox5.Text = name + formattedDate;
            // }

            // else
            //
            // {
            // MessageBox.Show("Такого пациента не существует");
            //comboBox1.Text = "";
            //
            //}
            // }

            long col = 100000000000000;
            long col2 = 999999999999999;

            Random random = new Random();
            byte[] buffer = new byte[8];
            random.NextBytes(buffer);

            long longRandom = BitConverter.ToInt64(buffer, 0);
            long result = (long)Math.Floor((double)(longRandom / (double)long.MaxValue * (col2 - col + 1))) + col;

            textBox5.Text = result.ToString();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Dobavlenie frm7 = new Dobavlenie();
            this.Hide();
            frm7.ShowDialog();
            this.Show();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {

            var FIO = textBox2.Text;
            var social_sec_number = textBox1.Text;
            var socialtyp = comboBox2.Text;
            var passport_n = textBox3.Text; 

            var query = $"insert into patients (fio,social_sec_number, social_type, passport_n) values ('{FIO}','{social_sec_number}','{socialtyp}', '{ passport_n}')";
            string id_patient = comboBox1.Text;
            using (SqlConnection connection = new SqlConnection(connectionString))
            using (SqlCommand command = new SqlCommand(query, connection))
            using (SqlCommand command1 = new SqlCommand(query1, connection))
            using (SqlCommand command2 = new SqlCommand(query2, connection))
            using (SqlCommand command3 = new SqlCommand(query3, connection))
            using (SqlCommand command4 = new SqlCommand(query4, connection))
            using (SqlCommand command5 = new SqlCommand(query4, connection))

            {
                command.Parameters.AddWithValue("@patient", id_patient);
                command1.Parameters.AddWithValue("@id", id_patient);
                command2.Parameters.AddWithValue("@id", id_patient);
                command3.Parameters.AddWithValue("@id", id_patient);
                command4.Parameters.AddWithValue("@id", id_patient);
                command5.Parameters.AddWithValue("@id", id_patient);

                connection.Open();
                string name = (string)command.ExecuteScalar();
                string name1 = (string)command1.ExecuteScalar();
                string name2 = (string)command2.ExecuteScalar();
                string name3 = (string)command3.ExecuteScalar();
                string name4 = (string)command4.ExecuteScalar();
                string name5 = (string)command4.ExecuteScalar();

                if (name != null)
                {
                    comboBox1.Text = name;
                    textBox2.Text = name1;
                    textBox3.Text = name2;
                    textBox1.Text = name3;
                    comboBox2.Text = name5;
                }



                else
                {
                    MessageBox.Show("Такого пациента не существует");
                    comboBox1.Text = "";
                }


            }
        }
    }
}
