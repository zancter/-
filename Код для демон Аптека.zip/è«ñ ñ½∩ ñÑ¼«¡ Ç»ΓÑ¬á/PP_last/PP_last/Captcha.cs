﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;

namespace PP_last
{
    public partial class Captcha_Form : Form
    {
        public Captcha_Form()
        {
            InitializeComponent();
            pictureBox1.Image = this.CreateImage(pictureBox1.Width, pictureBox1.Height);
            
        }

        string text = String.Empty;
        public Bitmap CreateImage(int Width, int Height)
        {
            text = String.Empty;
            Random rnd = new Random();

            //Создадие изображения
            Bitmap result = new Bitmap(Width, Height);

            // позиции текста
            int Xpos = 50;
            int Ypos = 30;

            //Перечисление цветов которые будут использоваться для кода проверки
            Brush[] colors =
                {
                    Brushes.Black,
                    Brushes.Red,
                    Brushes.RoyalBlue,
                    Brushes.Green,
                    Brushes.Yellow,
                    Brushes.White,
                    Brushes.Tomato,
                    Brushes.Sienna,
                    Brushes.Pink
                };

            //Добавление различных цветов линий
            Pen[] colorpens = {
            Pens.Black,
            Pens.Red,
            Pens.RoyalBlue,
            Pens.Green,
            Pens.Yellow,
            Pens.White,
            Pens.Tomato,
            Pens.Sienna,
            Pens.Pink };

            //Установка случайного стиля текста
            FontStyle[] fontstyle = {
            FontStyle.Bold,
            FontStyle.Italic,
            FontStyle.Regular,
            FontStyle.Strikeout,
            FontStyle.Underline};

            //Добавление различных углов поворота текста
            Int16[] rotate = { 1, -1, 2, -2, 3, -3, 4, -4, 5, -5, 6, -6 };

            //Указание места для отрисовки шума
            Graphics g = Graphics.FromImage((Image)result);

            //Установление цвета заднего фона
            g.Clear(Color.Black);

            //Установка случайного угла поворота текста
            g.RotateTransform(rnd.Next(rotate.Length));

            //Генерирация текста

            string ALF = "1234567890QWERTYUIOPASDFGHJKLZXCVBNM";
            for (int i = 0; i < 5; ++i)
                text += ALF[rnd.Next(ALF.Length)];

            //Отрисовка сгенирируемого текста
            g.DrawString(text,
            new Font("Comic Sans MS", 25, fontstyle[rnd.Next(fontstyle.Length)]),
            colors[rnd.Next(colors.Length)],
            new PointF(Xpos, Ypos));

            //Добление помех, линий и углов на изображение
            g.DrawLine(colorpens[rnd.Next(colorpens.Length)],
            new Point(0, 0),
            new Point(Width - 1, Height - 1));
            g.DrawLine(colorpens[rnd.Next(colorpens.Length)],
            new Point(0, Height - 1),
            new Point(Width - 1, 0));
            g.DrawLine(colorpens[rnd.Next(colorpens.Length)],
            new Point(0, Height - 5),
            new Point(Width - 21, 120));
            g.DrawLine(colorpens[rnd.Next(colorpens.Length)],
            new Point(0, Height - 1),
            new Point(Width - 30, 90));
            g.DrawLine(colorpens[rnd.Next(colorpens.Length)],
            new Point(0, Height - 1),
            new Point(Width - 19, 50));

            //Добавление шума на изображение
            for (int i = 0; i < Width; ++i)
                for (int j = 0; j < Height; ++j)
                    if (rnd.Next() % 50 == 0)
                        result.SetPixel(i, j, Color.Orange);

            return result;
        }

        private void Captcha_Load(object sender, EventArgs e)
        {

        }
        //Метод button1_Click закрывает форму капчи и возвращает на форму авторизации
        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                if (textBox1.Text == this.text)
                {
                    Form1 login = new Form1();
                    login.Show();
                    Captcha_Form frm5 = new Captcha_Form();
                    this.Hide();
                }
                else throw new Exception();  //Обработка исключения при неверном вводе капчи
            }
            catch (Exception)
            { 
                //При неверном вводе капчи вызывается окно с предупреждением 
                // и форма "замораживается" на 10 секунд
                MessageBox.Show("Неверный ввод! Повторите попытку через 10 секунд");
                button1.Enabled = false;
                button2.Enabled = false;
                textBox1.Enabled = false;
                Thread.Sleep(2000);
                button1.Enabled = true;
                button2.Enabled = true;
                textBox1.Enabled = true;
            }
        }
        //Метод button2_Click генерирует новую капчу
        private void button2_Click(object sender, EventArgs e)
        {
            pictureBox1.Image = this.CreateImage(pictureBox1.Width, pictureBox1.Height);
        }
    }
}
