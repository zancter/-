﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PP_last
{
    public partial class Bushgal_panel : Form
    {
        public Bushgal_panel()
        {
            InitializeComponent();
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void Bushgal_panel_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "aptekaDataSet12.services". При необходимости она может быть перемещена или удалена.
            this.servicesTableAdapter1.Fill(this.aptekaDataSet12.services);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "aptekaDataSet11.patients". При необходимости она может быть перемещена или удалена.
            this.patientsTableAdapter4.Fill(this.aptekaDataSet11.patients);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "aptekaDataSet10.patients". При необходимости она может быть перемещена или удалена.
            this.patientsTableAdapter3.Fill(this.aptekaDataSet10.patients);
            

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }
    }
}
