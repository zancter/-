﻿namespace PP_last
{
    partial class Bushgal_panel
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Bushgal_panel));
            this.aptekaDataSet = new PP_last.AptekaDataSet();
            this.aptekaDataSetBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.aptekaDataSet1 = new PP_last.AptekaDataSet1();
            this.patientsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.patientsTableAdapter = new PP_last.AptekaDataSet1TableAdapters.patientsTableAdapter();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.fioDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.emailDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.phoneDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.patientsBindingSource3 = new System.Windows.Forms.BindingSource(this.components);
            this.aptekaDataSet10 = new PP_last.AptekaDataSet10();
            this.patientsBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.aptekaDataSet2 = new PP_last.AptekaDataSet2();
            this.patientsTableAdapter1 = new PP_last.AptekaDataSet2TableAdapters.patientsTableAdapter();
            this.label1 = new System.Windows.Forms.Label();
            this.aptekaDataSet3 = new PP_last.AptekaDataSet();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.idDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.fioDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.socialsecnumberDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.socialtypeDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.passportsDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.passportnDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.patientsBindingSource4 = new System.Windows.Forms.BindingSource(this.components);
            this.aptekaDataSet11 = new PP_last.AptekaDataSet11();
            this.patientsBindingSource2 = new System.Windows.Forms.BindingSource(this.components);
            this.aptekaDataSet31 = new PP_last.AptekaDataSet3();
            this.patientsTableAdapter2 = new PP_last.AptekaDataSet3TableAdapters.patientsTableAdapter();
            this.label2 = new System.Windows.Forms.Label();
            this.dataGridView3 = new System.Windows.Forms.DataGridView();
            this.codeDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.seviceDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.priceDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.servicesBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.aptekaDataSet12 = new PP_last.AptekaDataSet12();
            this.servicesBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.aptekaDataSet4 = new PP_last.AptekaDataSet4();
            this.servicesTableAdapter = new PP_last.AptekaDataSet4TableAdapters.servicesTableAdapter();
            this.label3 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.patientsTableAdapter3 = new PP_last.AptekaDataSet10TableAdapters.patientsTableAdapter();
            this.patientsTableAdapter4 = new PP_last.AptekaDataSet11TableAdapters.patientsTableAdapter();
            this.servicesTableAdapter1 = new PP_last.AptekaDataSet12TableAdapters.servicesTableAdapter();
            ((System.ComponentModel.ISupportInitialize)(this.aptekaDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.aptekaDataSetBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.aptekaDataSet1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.patientsBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.patientsBindingSource3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.aptekaDataSet10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.patientsBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.aptekaDataSet2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.aptekaDataSet3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.patientsBindingSource4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.aptekaDataSet11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.patientsBindingSource2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.aptekaDataSet31)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.servicesBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.aptekaDataSet12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.servicesBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.aptekaDataSet4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // aptekaDataSet
            // 
            this.aptekaDataSet.DataSetName = "AptekaDataSet";
            this.aptekaDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // aptekaDataSetBindingSource
            // 
            this.aptekaDataSetBindingSource.DataSource = this.aptekaDataSet;
            this.aptekaDataSetBindingSource.Position = 0;
            // 
            // aptekaDataSet1
            // 
            this.aptekaDataSet1.DataSetName = "AptekaDataSet1";
            this.aptekaDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // patientsBindingSource
            // 
            this.patientsBindingSource.DataMember = "patients";
            this.patientsBindingSource.DataSource = this.aptekaDataSet1;
            // 
            // patientsTableAdapter
            // 
            this.patientsTableAdapter.ClearBeforeFill = true;
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.fioDataGridViewTextBoxColumn,
            this.emailDataGridViewTextBoxColumn,
            this.phoneDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.patientsBindingSource3;
            this.dataGridView1.Location = new System.Drawing.Point(580, 51);
            this.dataGridView1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(527, 250);
            this.dataGridView1.TabIndex = 5;
            // 
            // fioDataGridViewTextBoxColumn
            // 
            this.fioDataGridViewTextBoxColumn.DataPropertyName = "fio";
            this.fioDataGridViewTextBoxColumn.HeaderText = "fio";
            this.fioDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.fioDataGridViewTextBoxColumn.Name = "fioDataGridViewTextBoxColumn";
            this.fioDataGridViewTextBoxColumn.Width = 125;
            // 
            // emailDataGridViewTextBoxColumn
            // 
            this.emailDataGridViewTextBoxColumn.DataPropertyName = "email";
            this.emailDataGridViewTextBoxColumn.HeaderText = "email";
            this.emailDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.emailDataGridViewTextBoxColumn.Name = "emailDataGridViewTextBoxColumn";
            this.emailDataGridViewTextBoxColumn.Width = 125;
            // 
            // phoneDataGridViewTextBoxColumn
            // 
            this.phoneDataGridViewTextBoxColumn.DataPropertyName = "phone";
            this.phoneDataGridViewTextBoxColumn.HeaderText = "phone";
            this.phoneDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.phoneDataGridViewTextBoxColumn.Name = "phoneDataGridViewTextBoxColumn";
            this.phoneDataGridViewTextBoxColumn.Width = 125;
            // 
            // patientsBindingSource3
            // 
            this.patientsBindingSource3.DataMember = "patients";
            this.patientsBindingSource3.DataSource = this.aptekaDataSet10;
            // 
            // aptekaDataSet10
            // 
            this.aptekaDataSet10.DataSetName = "AptekaDataSet10";
            this.aptekaDataSet10.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // patientsBindingSource1
            // 
            this.patientsBindingSource1.DataMember = "patients";
            this.patientsBindingSource1.DataSource = this.aptekaDataSet2;
            // 
            // aptekaDataSet2
            // 
            this.aptekaDataSet2.DataSetName = "AptekaDataSet2";
            this.aptekaDataSet2.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // patientsTableAdapter1
            // 
            this.patientsTableAdapter1.ClearBeforeFill = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(118)))), ((int)(((byte)(227)))), ((int)(((byte)(131)))));
            this.label1.Font = new System.Drawing.Font("Comic Sans MS", 15.75F);
            this.label1.Location = new System.Drawing.Point(798, 11);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(146, 38);
            this.label1.TabIndex = 6;
            this.label1.Text = "пациенты";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // aptekaDataSet3
            // 
            this.aptekaDataSet3.DataSetName = "AptekaDataSet";
            this.aptekaDataSet3.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // dataGridView2
            // 
            this.dataGridView2.AutoGenerateColumns = false;
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.idDataGridViewTextBoxColumn,
            this.fioDataGridViewTextBoxColumn1,
            this.socialsecnumberDataGridViewTextBoxColumn,
            this.socialtypeDataGridViewTextBoxColumn,
            this.passportsDataGridViewTextBoxColumn,
            this.passportnDataGridViewTextBoxColumn});
            this.dataGridView2.DataSource = this.patientsBindingSource4;
            this.dataGridView2.Location = new System.Drawing.Point(12, 363);
            this.dataGridView2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.RowHeadersWidth = 51;
            this.dataGridView2.RowTemplate.Height = 24;
            this.dataGridView2.Size = new System.Drawing.Size(876, 171);
            this.dataGridView2.TabIndex = 7;
            // 
            // idDataGridViewTextBoxColumn
            // 
            this.idDataGridViewTextBoxColumn.DataPropertyName = "id";
            this.idDataGridViewTextBoxColumn.HeaderText = "id";
            this.idDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.idDataGridViewTextBoxColumn.Name = "idDataGridViewTextBoxColumn";
            this.idDataGridViewTextBoxColumn.Width = 125;
            // 
            // fioDataGridViewTextBoxColumn1
            // 
            this.fioDataGridViewTextBoxColumn1.DataPropertyName = "fio";
            this.fioDataGridViewTextBoxColumn1.HeaderText = "fio";
            this.fioDataGridViewTextBoxColumn1.MinimumWidth = 6;
            this.fioDataGridViewTextBoxColumn1.Name = "fioDataGridViewTextBoxColumn1";
            this.fioDataGridViewTextBoxColumn1.Width = 125;
            // 
            // socialsecnumberDataGridViewTextBoxColumn
            // 
            this.socialsecnumberDataGridViewTextBoxColumn.DataPropertyName = "social_sec_number";
            this.socialsecnumberDataGridViewTextBoxColumn.HeaderText = "social_sec_number";
            this.socialsecnumberDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.socialsecnumberDataGridViewTextBoxColumn.Name = "socialsecnumberDataGridViewTextBoxColumn";
            this.socialsecnumberDataGridViewTextBoxColumn.Width = 125;
            // 
            // socialtypeDataGridViewTextBoxColumn
            // 
            this.socialtypeDataGridViewTextBoxColumn.DataPropertyName = "social_type";
            this.socialtypeDataGridViewTextBoxColumn.HeaderText = "social_type";
            this.socialtypeDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.socialtypeDataGridViewTextBoxColumn.Name = "socialtypeDataGridViewTextBoxColumn";
            this.socialtypeDataGridViewTextBoxColumn.Width = 125;
            // 
            // passportsDataGridViewTextBoxColumn
            // 
            this.passportsDataGridViewTextBoxColumn.DataPropertyName = "passport_s";
            this.passportsDataGridViewTextBoxColumn.HeaderText = "passport_s";
            this.passportsDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.passportsDataGridViewTextBoxColumn.Name = "passportsDataGridViewTextBoxColumn";
            this.passportsDataGridViewTextBoxColumn.Width = 125;
            // 
            // passportnDataGridViewTextBoxColumn
            // 
            this.passportnDataGridViewTextBoxColumn.DataPropertyName = "passport_n";
            this.passportnDataGridViewTextBoxColumn.HeaderText = "passport_n";
            this.passportnDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.passportnDataGridViewTextBoxColumn.Name = "passportnDataGridViewTextBoxColumn";
            this.passportnDataGridViewTextBoxColumn.Width = 125;
            // 
            // patientsBindingSource4
            // 
            this.patientsBindingSource4.DataMember = "patients";
            this.patientsBindingSource4.DataSource = this.aptekaDataSet11;
            // 
            // aptekaDataSet11
            // 
            this.aptekaDataSet11.DataSetName = "AptekaDataSet11";
            this.aptekaDataSet11.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // patientsBindingSource2
            // 
            this.patientsBindingSource2.DataMember = "patients";
            this.patientsBindingSource2.DataSource = this.aptekaDataSet31;
            // 
            // aptekaDataSet31
            // 
            this.aptekaDataSet31.DataSetName = "AptekaDataSet3";
            this.aptekaDataSet31.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // patientsTableAdapter2
            // 
            this.patientsTableAdapter2.ClearBeforeFill = true;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(118)))), ((int)(((byte)(227)))), ((int)(((byte)(131)))));
            this.label2.Font = new System.Drawing.Font("Comic Sans MS", 15.75F);
            this.label2.Location = new System.Drawing.Point(213, 323);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(101, 38);
            this.label2.TabIndex = 8;
            this.label2.Text = "заявки";
            // 
            // dataGridView3
            // 
            this.dataGridView3.AutoGenerateColumns = false;
            this.dataGridView3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView3.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.codeDataGridViewTextBoxColumn,
            this.seviceDataGridViewTextBoxColumn,
            this.priceDataGridViewTextBoxColumn});
            this.dataGridView3.DataSource = this.servicesBindingSource1;
            this.dataGridView3.Location = new System.Drawing.Point(3, 51);
            this.dataGridView3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.dataGridView3.Name = "dataGridView3";
            this.dataGridView3.RowHeadersWidth = 51;
            this.dataGridView3.RowTemplate.Height = 24;
            this.dataGridView3.Size = new System.Drawing.Size(554, 250);
            this.dataGridView3.TabIndex = 9;
            // 
            // codeDataGridViewTextBoxColumn
            // 
            this.codeDataGridViewTextBoxColumn.DataPropertyName = "code";
            this.codeDataGridViewTextBoxColumn.HeaderText = "code";
            this.codeDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.codeDataGridViewTextBoxColumn.Name = "codeDataGridViewTextBoxColumn";
            this.codeDataGridViewTextBoxColumn.Width = 125;
            // 
            // seviceDataGridViewTextBoxColumn
            // 
            this.seviceDataGridViewTextBoxColumn.DataPropertyName = "sevice";
            this.seviceDataGridViewTextBoxColumn.HeaderText = "sevice";
            this.seviceDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.seviceDataGridViewTextBoxColumn.Name = "seviceDataGridViewTextBoxColumn";
            this.seviceDataGridViewTextBoxColumn.Width = 125;
            // 
            // priceDataGridViewTextBoxColumn
            // 
            this.priceDataGridViewTextBoxColumn.DataPropertyName = "price";
            this.priceDataGridViewTextBoxColumn.HeaderText = "price";
            this.priceDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.priceDataGridViewTextBoxColumn.Name = "priceDataGridViewTextBoxColumn";
            this.priceDataGridViewTextBoxColumn.Width = 125;
            // 
            // servicesBindingSource1
            // 
            this.servicesBindingSource1.DataMember = "services";
            this.servicesBindingSource1.DataSource = this.aptekaDataSet12;
            // 
            // aptekaDataSet12
            // 
            this.aptekaDataSet12.DataSetName = "AptekaDataSet12";
            this.aptekaDataSet12.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // servicesBindingSource
            // 
            this.servicesBindingSource.DataMember = "services";
            this.servicesBindingSource.DataSource = this.aptekaDataSet4;
            // 
            // aptekaDataSet4
            // 
            this.aptekaDataSet4.DataSetName = "AptekaDataSet4";
            this.aptekaDataSet4.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // servicesTableAdapter
            // 
            this.servicesTableAdapter.ClearBeforeFill = true;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(118)))), ((int)(((byte)(227)))), ((int)(((byte)(131)))));
            this.label3.Font = new System.Drawing.Font("Comic Sans MS", 15.75F);
            this.label3.Location = new System.Drawing.Point(213, 9);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(106, 38);
            this.label3.TabIndex = 10;
            this.label3.Text = "услуги";
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(901, 363);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(195, 165);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 13;
            this.pictureBox1.TabStop = false;
            // 
            // patientsTableAdapter3
            // 
            this.patientsTableAdapter3.ClearBeforeFill = true;
            // 
            // patientsTableAdapter4
            // 
            this.patientsTableAdapter4.ClearBeforeFill = true;
            // 
            // servicesTableAdapter1
            // 
            this.servicesTableAdapter1.ClearBeforeFill = true;
            // 
            // Bushgal_panel
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1109, 554);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.dataGridView3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.dataGridView2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dataGridView1);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Bushgal_panel";
            this.Text = "Bushgal_panel";
            this.Load += new System.EventHandler(this.Bushgal_panel_Load);
            ((System.ComponentModel.ISupportInitialize)(this.aptekaDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.aptekaDataSetBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.aptekaDataSet1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.patientsBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.patientsBindingSource3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.aptekaDataSet10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.patientsBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.aptekaDataSet2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.aptekaDataSet3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.patientsBindingSource4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.aptekaDataSet11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.patientsBindingSource2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.aptekaDataSet31)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.servicesBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.aptekaDataSet12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.servicesBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.aptekaDataSet4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private AptekaDataSet aptekaDataSet;
        private System.Windows.Forms.BindingSource aptekaDataSetBindingSource;
        private AptekaDataSet1 aptekaDataSet1;
        private System.Windows.Forms.BindingSource patientsBindingSource;
        private AptekaDataSet1TableAdapters.patientsTableAdapter patientsTableAdapter;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.DataGridViewTextBoxColumn fioDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn emailDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn phoneDataGridViewTextBoxColumn;
        private AptekaDataSet2 aptekaDataSet2;
        private System.Windows.Forms.BindingSource patientsBindingSource1;
        private AptekaDataSet2TableAdapters.patientsTableAdapter patientsTableAdapter1;
        private System.Windows.Forms.Label label1;
        private AptekaDataSet aptekaDataSet3;
        private System.Windows.Forms.DataGridView dataGridView2;
        private AptekaDataSet3 aptekaDataSet31;
        private System.Windows.Forms.BindingSource patientsBindingSource2;
        private AptekaDataSet3TableAdapters.patientsTableAdapter patientsTableAdapter2;
        private System.Windows.Forms.DataGridViewTextBoxColumn idDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn fioDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn socialsecnumberDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn socialtypeDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn passportsDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn passportnDataGridViewTextBoxColumn;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.DataGridView dataGridView3;
        private AptekaDataSet4 aptekaDataSet4;
        private System.Windows.Forms.BindingSource servicesBindingSource;
        private AptekaDataSet4TableAdapters.servicesTableAdapter servicesTableAdapter;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.PictureBox pictureBox1;
        private AptekaDataSet10 aptekaDataSet10;
        private System.Windows.Forms.BindingSource patientsBindingSource3;
        private AptekaDataSet10TableAdapters.patientsTableAdapter patientsTableAdapter3;
        private AptekaDataSet11 aptekaDataSet11;
        private System.Windows.Forms.BindingSource patientsBindingSource4;
        private AptekaDataSet11TableAdapters.patientsTableAdapter patientsTableAdapter4;
        private AptekaDataSet12 aptekaDataSet12;
        private System.Windows.Forms.BindingSource servicesBindingSource1;
        private AptekaDataSet12TableAdapters.servicesTableAdapter servicesTableAdapter1;
        private System.Windows.Forms.DataGridViewTextBoxColumn codeDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn seviceDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn priceDataGridViewTextBoxColumn;
    }
}