﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace PP_last
{
    public partial class Bugalt_Form : Form
    {
        public Bugalt_Form()
        {
            InitializeComponent();
            StartPosition = FormStartPosition.CenterScreen;
        }

        private void Bugalt_Form_Load(object sender, EventArgs e)
        {
            string connectionString = @"Data Source=DESKTOP-0133EL8\SQL5;Initial Catalog=Apteka;Integrated Security=True";
            string query = "SELECT name FROM users WHERE type = @type";

            using (SqlConnection connection = new SqlConnection(connectionString))
            using (SqlCommand command = new SqlCommand(query, connection))
            {
                command.Parameters.AddWithValue("type", 3);

                connection.Open();
                string name = (string)command.ExecuteScalar();
                label2.Text = name;

            }
        }

        private void button2_Click(object sender, EventArgs e)
        {

            Bushgal_panel frm8 = new Bushgal_panel();
            this.Hide();
            frm8.ShowDialog();
            this.Show();
            
        }
    }
}
