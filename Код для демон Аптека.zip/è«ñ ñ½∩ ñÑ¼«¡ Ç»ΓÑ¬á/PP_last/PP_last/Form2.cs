﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;

namespace PP_last
{

    enum RowState
    {
        Existed,
        New,
        Modified,
        ModifiedNew,
        Deleted
    }
    public partial class Admin_form : Form
    {
        DataBase dataBase = new DataBase();

        public Admin_form()
        {
            InitializeComponent();
            StartPosition = FormStartPosition.CenterScreen;
        }


        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void Admin_form_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "aptekaDataSet9.users". При необходимости она может быть перемещена или удалена.
            this.usersTableAdapter1.Fill(this.aptekaDataSet9.users);
            string connectionString = @"Data Source=DESKTOP-0133EL8\SQL5;Initial Catalog=Apteka;Integrated Security=True";
            string query = "SELECT name FROM users WHERE type = @type";

            using (SqlConnection connection = new SqlConnection(connectionString))
            using (SqlCommand command = new SqlCommand(query, connection))

                
            
            {
                command.Parameters.AddWithValue("type", 1);

                connection.Open();
                string name = (string)command.ExecuteScalar();
                label2.Text = name;
                

            }





        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void dataGridView1_CellContentClick_1(object sender, DataGridViewCellEventArgs e)
        {
        
        }
    }
}
