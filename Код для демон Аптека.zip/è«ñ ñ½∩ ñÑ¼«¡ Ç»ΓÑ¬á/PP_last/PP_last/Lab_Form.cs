﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace PP_last
{
    public partial class Lab_Form : Form
    {
        public Lab_Form()
        {
            InitializeComponent();
            StartPosition = FormStartPosition.CenterScreen;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Registration frm6 = new Registration();
            this.Hide();
            frm6.ShowDialog();
            this.Show();
        }

        private void Lab_Form_Load(object sender, EventArgs e)
        {
            string connectionString = @"Data Source=DESKTOP-0133EL8\SQL5;Initial Catalog=Apteka;Integrated Security=True";
            string query = "SELECT name FROM users WHERE type = @type";

            using (SqlConnection connection = new SqlConnection(connectionString))
            using (SqlCommand command = new SqlCommand(query, connection))
            {
                command.Parameters.AddWithValue("type", 2);

                connection.Open();
                string name = (string)command.ExecuteScalar();
                label2.Text = name;

            }
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
